

<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Data Layanan UMKM</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="/dashboard">
                            <i class="flaticon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Data</a>
                    </li>
                    <li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#"> Layanan UMKM</a>
                    </li>
                </ul>
            </div>
            <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">Data Layanan UMKM</h4>
                                <button class="btn btn-primary btn-round ml-auto" data-toggle="modal" data-target="#modalAddPelakuUsaha">
                                    <i class="fa fa-plus"></i>
                                    Create
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Modal -->

                            <div class="table-responsive">
                                <table id="add-row" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Pelaku Usaha</th>
                                            <th>Alamat Pelaku Usaha</th>
                                            <th>Telp Pelaku Usaha</th>
                                            <th>Deskripsi Pelaku Usaha</th>
                                            <th>Sejarah Pelaku Usaha</th>
                                            <th>Tipe Usaha</th>
                                            <th>Image Pelaku Usaha</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1 ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $layanan_umkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($layanan_umkm->usaha_nama); ?></td>
                                            <td><?php echo e($layanan_umkm->usaha_alamat); ?></td>
                                            <td><?php echo e($layanan_umkm->usaha_telp); ?></td>
                                            <td><?php echo e($layanan_umkm->usaha_deskripsi); ?></td>
                                            <td><?php echo e($layanan_umkm->usaha_sejarah); ?></td>
                                            <td><?php echo e($layanan_umkm->usaha_tipe); ?></td>
                                            <td><img width="150px" src="<?php echo e(url('/data_file/'.$layanan_umkm->usaha_img)); ?>"></td>

                                            <td>
                                                <div>

                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>

                                                    <a href="#modalEditlayanan_umkm<?php echo e($layanan_umkm->usaha_id); ?>" data-toggle="modal" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i>Edit</a>
                                                    <a href="#modalHapuslayanan_umkm<?php echo e($layanan_umkm->usaha_id); ?>" data-toggle="modal" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i>Hapus</a>
                                                    <!-- </form> -->
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="modalAddPelakuUsaha" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add Pelaku Usaha</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="/add_pelaku_usaha" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="form-grup">
                        <label>Nama Pelaku Usaha</label>
                        <input type="text" class="form-control" name="usaha_nama" placeholder="Nama Pelaku Usaha ..." required>
                    </div>
                    <div class="form-grup">
                        <label>Alamat Pelaku Usaha</label>
                        <input type="text" class="form-control" name="usaha_alamat" placeholder="Alamat Pelaku Usaha ..." required>
                    </div>

                    <div class="form-grup">
                        <label>Telp Pelaku Usaha</label>
                        <input type="text" class="form-control" name="usaha_telp" placeholder="Telp Pelaku Usaha ..." required>
                    </div>

                    <div class="form-grup">
                        <label>Desk Pelaku Usaha</label>
                        <textarea class="form-control" name="usaha_deskripsi" placeholder="Desk Pelaku Usaha ..."></textarea>
                    </div>

                    <div class="form-grup">
                        <label>Sejarah Pelaku Usaha</label>
                        <textarea class="form-control" name="usaha_sejarah" placeholder="Sejarah Pelaku Usaha ..."></textarea>
                    </div>

                    <div class="form-group">
                        <label>Tipe Usahak</label>
                        <select class="form-control" name="usaha_tipe" id="item_id" required>
                            <option value="" hidden="">--Pilih Usaha--</option>
                            <option>Dinamo</option>
                            <option>UMKM</option>
                            <option>Layanan Masyarakat</option>
                            <option>Bratang Market</option>
                        </select>
                    </div>
                    <div class="form-grup">
                        <label>Foto</label><br>
                        <input type="file" name="usaha_img">
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-undo"></i>Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>



//edit

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalEditlayanan_umkm<?php echo e($g->usaha_id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="/edit_pelaku_usaha/<?php echo e($g->usaha_id); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e($g->usaha_id); ?>" name="id" required>
                <div class="modal-body">
                    <div class="form-grup">
                        <label>Nama Pelaku Usaha</label>
                        <input type="text" class="form-control" name="usaha_nama" value="<?php echo e($g->usaha_nama); ?>" placeholder="Nama Pelaku Usaha ..." required>
                    </div>
                    <div class="form-grup">
                        <label>Alamat Pelaku Usaha</label>
                        <input type="text" class="form-control" name="usaha_alamat" value="<?php echo e($g->usaha_alamat); ?>" placeholder="Alamat Pelaku Usaha ..." required>
                    </div>

                    <div class="form-grup">
                        <label>Telp Pelaku Usaha</label>
                        <input type="text" class="form-control" name="usaha_telp" value="<?php echo e($g->usaha_telp); ?>" placeholder="Telp Pelaku Usaha ..." required>
                    </div>

                    <div class="form-grup">
                        <label>Desk Pelaku Usaha</label>
                        <textarea class="form-control" name="usaha_deskripsi" placeholder="Desk Pelaku Usaha ..."><?php echo e($g->usaha_deskripsi); ?></textarea>
                    </div>

                    <div class="form-grup">
                        <label>Sejarah Pelaku Usaha</label>
                        <textarea class="form-control" name="usaha_sejarah" placeholder="Sejarah Pelaku Usaha ..."><?php echo e($g->usaha_sejarah); ?></textarea>
                    </div>

                    <div class="form-grup">
                        <label>Keahlian Pelaku Usaha</label>
                        <input type="text" class="form-control" name="usaha_keahlian" value="<?php echo e($g->usaha_keahlian); ?>" placeholder="Keahlian Pelaku Usaha ..." required>
                    </div>
                    <div class="form-grup">
                        <label>Foto</label><br>
                        <img src="<?php echo e(url('/data_file/'.$g->usaha_img)); ?>" width="200px" height="200px" alt="">
                        <input type="file" name="usaha_img" src="<?php echo e(url('/data_file/'.$g->usaha_img)); ?>">
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-undo"></i>Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

//hapus data

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $la): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalHapuslayanan_umkm<?php echo e($la->usaha_id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Hapus Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="GET" enctype="multipart/form-data" action="/delete_pelaku_usaha/{id}">
                <?php echo csrf_field(); ?>
                <div class="modal-body">

                    <input type="hidden" value="<?php echo e($la->usaha_id); ?>" name="id" required>

                    <div class="form-grup">
                        <h4>Apakah anda ingin menghapus data ini?</h4>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-undo"></i>Close</button>
                        <button type="submit" class="btn btn-danger"> <i class="fa fa-trash"></i>Hapus Data</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\desa_profil\website_desa\resources\views/admin/layanan_umkm/index.blade.php ENDPATH**/ ?>