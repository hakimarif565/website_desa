

<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Data Produk Ecommerce</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="/dashboard">
                            <i class="flaticon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Data</a>
                    </li>
                    <li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Produk</a>
                    </li>
                </ul>
            </div>
            <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title">Data Produk</h4>
                                <button class="btn btn-primary btn-round ml-auto" data-toggle="modal" data-target="#modalAddProdukE">
                                    <i class="fa fa-plus"></i>
                                    Create
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <!-- Modal -->

                            <div class="table-responsive">
                                <table id="add-row" class="display table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Produk</th>
                                            <th>Produk 1</th>
                                            <th>Produk 2</th>
                                            <th>Produk 3</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i = 1 ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk_ecommerce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($produk_ecommerce->item_name); ?></td>
                                            <td><?php echo e($produk_ecommerce->produk_ecommerce_link1); ?></td>
                                            <td><?php echo e($produk_ecommerce->produk_ecommerce_link2); ?></td>
                                            <td><?php echo e($produk_ecommerce->produk_ecommerce_link3); ?></td>
                                            <td>
                                                <div>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <a href="#" data-toggle="modal" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i>Edit</a>
                                                    <a href="#" data-toggle="modal" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i>Hapus</a>
                                                    <!-- </form> -->
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

// add data

<div class="modal fade" id="modalAddProdukE" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Add Produk</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="/add_produk_ecommerce" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">

                    <div class="form-group">
                        <label>Nama Produk</label>
                        <select class="form-control" name="item_id" id="item_id" required>
                            <option value="" hidden="">--Pilih Produk--</option>
                            <?php $__currentLoopData = $produk_layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($d->item_id); ?>"><?php echo e($d->item_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Nama Ecommerce</label>
                        <select class="form-control" name="ecommerce_id" id="ecommerce_id" required>
                            <option value="" hidden="">--Pilih Produk--</option>
                            <?php $__currentLoopData = $ecommerce; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($d->ecommerce_id); ?>"><?php echo e($d->ecommerce_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-grup">
                        <label>Link 1</label>
                        <input type="text" class="form-control" name="produk_ecommerce_link1" placeholder="Link1 ..." required>
                    </div>

                    <div class="form-grup">
                        <label>Link 2</label>
                        <input type="text" class="form-control" name="produk_ecommerce_link2" placeholder="Link2 ..." required>
                    </div>

                    <div class="form-grup">
                        <label>Link 3</label>
                        <input type="text" class="form-control" name="produk_ecommerce_link3" placeholder="Link3 ..." required>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-undo"></i>Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- 
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal fade" id="modalEditProduk<?php echo e($g->item_id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Edit Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="/edit_produk/<?php echo e($g->item_id); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e($g->item_id); ?>" name="id" required>
                <div class="modal-body">
                    <div class="form-grup">
                        <label>Nama Produk</label>
                        <input type="text" class="form-control" name="item_name" value="<?php echo e($g->item_name); ?>" placeholder="Nama Produk ..." required>
                    </div>
                    <div class="form-grup">
                        <label>Deskripsi</label>
                        <input type="text" class="form-control" name="item_deskripsi" value="<?php echo e($g->item_deskripsi); ?>" placeholder="Deskripsi ..." required>
                    </div>

                    <div class="form-grup">
                        <label>Harga</label>
                        <input type="text" class="form-control" name="item_harga" value="<?php echo e($g->item_harga); ?>" placeholder="Harga ..." required>
                    </div>

                    <div class="form-grup">
                        <label>Etc</label>
                        <input type="text" class="form-control" name="item_dll" value="<?php echo e($g->item_dll); ?>" placeholder="Etc ..." required>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-undo"></i>Close</button>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalHapusProduk<?php echo e($p->item_id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Hapus Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="GET" enctype="multipart/form-data" action="/delete_produk/{id}">
                <?php echo csrf_field(); ?>
                <div class="modal-body">

                    <input type="hidden" value="<?php echo e($p->item_id); ?>" name="id" required>

                    <div class="form-grup">
                        <h4>Apakah anda ingin menghapus data ini?</h4>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-undo"></i>Close</button>
                        <button type="submit" class="btn btn-danger"> <i class="fa fa-trash"></i>Hapus Data</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->


<script src="/assets/js/core/jquery.3.2.1.min.js"></script>

<script type="text/javascript">
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').str('content')
        }
    });
</script>

<script type="text/javascript">
    $("#item_id").change(function() {
        var id_book_msk = $("#id_book_msk").val();
        $.ajax({
            type: "GET",
            url: "/produk_ecommerce/ajax",
            data: "item_id=" + item_id,
            cache: false,
            success: function(data) {
                $('#item_id').html(data);
            }
        })
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\desa_profil\website_desa\resources\views/admin/produk_ecommerce/index.blade.php ENDPATH**/ ?>